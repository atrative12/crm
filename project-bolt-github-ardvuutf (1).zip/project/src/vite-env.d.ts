/// <reference types="vite/client" />
declare module 'react-leaflet-heatmap-layer-v3';